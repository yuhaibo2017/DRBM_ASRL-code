function  [fitnessbestn1] = DRBM_ASRL(fname,ndv,maxfes,Xmin,Xmax)
        
    F=0.8;%scaling factor 
    CR=1;%crossover rate 
    mutationStrategy=1;
    mutationStrategy2=4;
    crossStrategy=1;
    i1 =0;
    FUN = @(x)feval(fname,x);
    myFN = fname;  
    npoints = 80;  
    i1=npoints;
   % Initial LHS samples
    X = zeros(npoints, ndv);    
    lu = [Xmin.* ones(1, ndv); Xmax.* ones(1, ndv)];
    XRRmin = repmat(lu(1, :), npoints, 1);
    XRRmax = repmat(lu(2, :), npoints, 1);
    X = XRRmin + (XRRmax - XRRmin) .* lhsdesign(npoints, ndv); 
     
    numb = 0;
    m2 = npoints;
    for ii=1:m2
        Y(ii,:)= feval(myFN, X(ii,:));          
    end
    
    C= min(Y);
    number = npoints;
   
    DB = [X,Y];
    DB = sortrows(DB,ndv+1);
    X = DB(:,1:ndv);
    Y = DB(:,ndv+1);
    fitnessbestn1 = Y;
    alp = 0.1;                   
    gammaa = 0.9;
    State = 1;  

    Q_Agent = [   0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;
                  0.50 0.50 0.50 0.50;];
    a1=0;
    a2=0;
    a3=0;
    a4=0;

    while(number<maxfes)

         r = 0; action_success = 0;
         Qvalue = Q_Agent(State,:); 
         temp = exp(Qvalue);
         ratio = cumsum(temp)/sum(temp); 
         jtemp = find(rand(1)<ratio);
         Action = jtemp(1); 
         
        if Action == 1 %Source space search strategy:Global surrogate search strategy
            flag2 ='cubic';
            panduan = DB(1,end);
            c= size(DB,1); 
            [lambda, gamma]= RBF(DB(1:c,1:ndv),DB(1:c,end),flag2);
            fhd2= @(x)RBF_eval(x,DB(1:c,1:ndv),lambda,gamma,flag2);
        
            point2 =DB(1:c,1:ndv);
            initialpoint2 = point2(randi(size(DB(1:c,1:ndv),1)),:); 
            FE=3000;L=lu(1,:);U=lu(2,:);
            options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-12,'GradObj','off');
            gbestxx2= fmincon(fhd2,initialpoint2,[],[],[],[],L,U,[],options);
            %X-DE
            bestNN_XX2=DB(1,1:ndv);
            V2=mutation(DB(1:c,1:ndv),bestNN_XX2,F,mutationStrategy,size(DB(1:c,1:ndv),1));
            be_v2=repmat(gbestxx2,size(DB(1:c,1:ndv),1),1);
        
            U21=crossover(DB(1:c,1:ndv),V2,CR,crossStrategy);
            U22=crossover(DB(1:c,1:ndv),be_v2,CR,crossStrategy);
            U2_0=[U21;U22];U2_0 =U2_0(randperm(size(U2_0,1),npoints),:);
            U2 = [gbestxx2;U2_0];
            f_Model2=fhd2(U2); f_hd2=[U2,f_Model2];
        
            f_hd2 =unique(f_hd2,"rows"); 
            f_hd2 = sortrows(f_hd2,ndv+1);
            dbest = f_hd2(1,1:ndv); Y_2= feval(myFN, dbest); 
            X_n1 = [dbest,Y_2];
            DB = [DB;X_n1];
            DB = sortrows(DB,ndv+1);
            number = number+1;
            fes = maxfes - number;
            a1 = a1 + 1;
            if Y_2<panduan
                action_success = 1; r = 1;
            end
        
         elseif Action == 2 %Source space search strategy:Local surrogate search strategy
         
            flag1 ='cubic';
            X2 = DB(1:npoints,1:ndv); 
            ds2 =2*ndv+1;
            if size(DB,1)<ds2
                mappedXQ= DB(:,1:ndv); 
                YQ= DB(:,end);
            else
                mappedXQ= DB(1:ds2,1:ndv);
                YQ= DB(1:ds2,end);
            end
        
            [lambda, gamma]= RBF(mappedXQ,YQ,flag1);
            fhd1= @(x)RBF_eval(x,mappedXQ,lambda,gamma,flag1);
            maxgen=100*ndv; minerror=1e-12;
            [gbestxx1,~] = DE(ndv,maxgen,fhd1, minerror, mappedXQ);
        
            %X-DE
            bestNN_XX1=mappedXQ(1,:);
            panduan = DB(1,end);
            V1=mutation(X2,bestNN_XX1,F,mutationStrategy2,size(X2,1));
            be_v1=repmat(gbestxx1,size(X2,1),1);
        
            U11=crossover(X2,V1,CR,crossStrategy);
            U12=crossover(X2,be_v1,CR,crossStrategy);
            U1_0=[U11;U12];U1_0=U1_0(randperm(size(U1_0,1),npoints),:);
            U1 = [gbestxx1;U1_0];
            f_Model1 =fhd1(U1); 
            f_hd1=[U1,f_Model1];
        
            f_hd1 =unique(f_hd1,"rows"); 
            f_hd1 = sortrows(f_hd1,ndv+1);
            dbest = f_hd1(1,1:ndv); Y_2= feval(myFN, dbest); 
            X_n1 = [dbest,Y_2];
            DB = [DB;X_n1];
            DB = sortrows(DB,ndv+1);
            number = number+1;
            fes = maxfes - number;
            a2 = a2 + 1;
            if Y_2<panduan
                action_success = 1; r = 1;
            end
        % Subspace search strategy
        elseif Action == 3
            D_t = DB(1:npoints,1:ndv);          
            original_x = D_t(:,1:ndv);
            original_y = D_t(:,end);
            Dr_space = 5;
            panduan = DB(1,end);

            [reconstructed_x] = RBM_reconstruction(original_x, Dr_space);
            flag ='cubic';
            [lambda, gamma]=RBF(reconstructed_x,original_y,flag);
            fhd1=@(x) RBF_eval(x,reconstructed_x,lambda,gamma,flag);
            maxgen=50*Dr_space; minerror=1e-12;
            [gbestx1,~] = DE(Dr_space,maxgen,fhd1, minerror,reconstructed_x); 
    
            mappedXQ = reconstructed_x;
            XDB_distance1 = real(sqrt(mappedXQ.^2*ones(size( gbestx1'))+ones(size(mappedXQ))*( gbestx1').^2-2*mappedXQ*( gbestx1')));
            maxd = max(XDB_distance1)+1;
            [~,idx] =sort(XDB_distance1,'ascend');
            sample =mappedXQ(idx(1:5,:),:);
            Tbest =[gbestx1;sample];

            bestNN_X1=mappedXQ(1,:);
            V=mutation(Tbest,bestNN_X1,F,mutationStrategy,size(Tbest,1));
            U=crossover(Tbest,V,CR,crossStrategy);
            Tbest =combine(Tbest,U);
            
            V=mutation(Tbest,bestNN_X1,F,mutationStrategy,size(Tbest,1)); 
            U=crossover(Tbest,V,CR,crossStrategy);
            Tbest =combine(Tbest,U);
             
            V=mutation(Tbest,bestNN_X1,F,mutationStrategy,size(Tbest,1));
            U=crossover(Tbest,V,CR,crossStrategy);       
            Tbest =combine(Tbest,U);
              
            V=mutation(Tbest,bestNN_X1,F,mutationStrategy,size(Tbest,1));
            U=crossover(Tbest,V,CR,crossStrategy);
            Tbest =combine(Tbest,U); 
 
            V=mutation(Tbest,bestNN_X1,F,mutationStrategy,size(Tbest,1));
            U=crossover(Tbest,V,CR,crossStrategy);
            Tbest =combine(Tbest,U); 
    
            de_num = size(Tbest,1);
            dn =npoints; 
            if de_num>=dn
                Tbest = Tbest(randperm(de_num,dn),:);
            else
                ad_num= dn-size(Tbest,1); ad_sample =mappedXQ(2:ad_num+1,:);
                Tbest =combine(Tbest,ad_sample);
            end
           reconstructed_xn = Tbest;
           [original_xn] = RBM_reconstruction2(reconstructed_xn, ndv);
    
            m3 = size(original_xn,1);
            for ia=1:m3
                xxi(ia,:) = entropy(original_xn(ia,:));   
            end 
            [~,idx3] =sort(xxi,'ascend');
            dbest =original_xn(idx3(end),:);
        
             Y_2= feval(myFN, dbest);
             X_n1 = [dbest,Y_2];
             DB = [DB;X_n1];
             DB = sortrows(DB,ndv+1);
             number = number+1;
             fes = maxfes - number;
             a3 = a3 + 1;
             if Y_2<panduan
                 action_success = 1; r = 1;
             end

        else 
            D_t2= DB(1:npoints,1:ndv);
            original_x2 = D_t2(:,1:ndv);
            original_y2 = D_t2(:,end);
            Dr_space2 = 10;
            panduan = DB(1,end);

            [reconstructed_x2] = RBM_reconstruction(original_x2, Dr_space2);
            flag2 ='cubic';
            [lambda, gamma]=RBF(reconstructed_x2,original_y2,flag2);
            fhd2=@(x) RBF_eval(x,reconstructed_x2,lambda,gamma,flag2);
            maxgen=50*Dr_space2; minerror=1e-12;
            [gbestx2,~] = DE(Dr_space2,maxgen,fhd2, minerror,reconstructed_x2); 
    
            mappedXQ2 = reconstructed_x2;
            XDB_distance2 = real(sqrt(mappedXQ2.^2*ones(size( gbestx2'))+ones(size(mappedXQ2))*( gbestx2').^2-2*mappedXQ2*( gbestx2')));
            [~,idx2] =sort(XDB_distance2,'ascend');
            sample2 =mappedXQ2(idx2(1:5,:),:);
            Tbest2 =[gbestx2;sample2];
            bestNN_X2=mappedXQ2(1,:);
            V2=mutation(Tbest2,bestNN_X2,F,mutationStrategy,size(Tbest2,1));
            U2=crossover(Tbest2,V2,CR,crossStrategy);
            Tbest2 =combine(Tbest2,U2);
            
            V2=mutation(Tbest2,bestNN_X2,F,mutationStrategy,size(Tbest2,1));
            U2=crossover(Tbest2,V2,CR,crossStrategy);
            Tbest2 =combine(Tbest2,U2);     
            V2=mutation(Tbest2,bestNN_X2,F,mutationStrategy,size(Tbest2,1));
            U2=crossover(Tbest2,V2,CR,crossStrategy);     
            Tbest2 =combine(Tbest2,U2);   
            V2=mutation(Tbest2,bestNN_X2,F,mutationStrategy,size(Tbest2,1));
            U2=crossover(Tbest2,V2,CR,crossStrategy);
            Tbest2 =combine(Tbest2,U2);  
            V2=mutation(Tbest2,bestNN_X2,F,mutationStrategy,size(Tbest2,1));
            U2=crossover(Tbest2,V2,CR,crossStrategy);
            Tbest2 =combine(Tbest2,U2); 
    
            de_num2 = size(Tbest2,1);
            dn =npoints; 
            if de_num2>=dn
                Tbest2 = Tbest2(randperm(de_num2,dn),:);
            else
                ad_num2= dn-size(Tbest2,1); ad_sample2 =mappedXQ2(2:ad_num2+1,:);
                Tbest2 =combine(Tbest2,ad_sample2);
            end
           reconstructed_xn2 = Tbest2;
           [original_xn2] = RBM_reconstruction2(reconstructed_xn2, ndv);

           m4 = size(original_xn2,1);
           for iia=1:m4
                xxi(iia,:) = entropy(original_xn2(iia,:));   
           end 
           [~,idx4] =sort(xxi,'ascend');
           dbest =original_xn2(idx4(end),:);
        
            Y_2= feval(myFN, dbest); 
            X_n1 = [dbest,Y_2];
            DB = [DB;X_n1];
            DB = sortrows(DB,ndv+1);
            number = number+1;
            fes = maxfes - number;
            a4 = a4 + 1;
            if Y_2<panduan
             action_success = 1; r = 1;
            end
       end

        State_Next = 2*Action+action_success-1; 
        temp = max(Q_Agent(State_Next,:));
        Q_Agent(State,Action) = (1-alp)*Q_Agent(State, Action)+alp.*(r+gammaa*temp);
        State = State_Next;

        if fes >= 0        
            X = DB(1:npoints,1:ndv); Y = DB(1:npoints,ndv+1); 
            i1= i1+1;
            fitnessbestn1(i1,1) = DB(1,end); 
        else
                break;  
        end
    end

end