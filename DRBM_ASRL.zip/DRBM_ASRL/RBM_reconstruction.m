function [reconstructed_x] = RBM_reconstruction(original_x, Dr_space)
    
    [train_x,ps]=mapminmax(original_x,0,1);
    sizes = Dr_space;   % hidden layer size(The dimension of reconstructed space)
    [opts, valid_fields] = dbncreateopts();

    opts.numepochs = 10;
    opts.traintype = 'CD';
    opts.classRBM = 0;
    opts.y_train = train_x;
    opts.test_interval = 1;
    opts.train_func = @rbmgenerative;
    opts.init_type = 'cRBM';
    
    opts.learningrate = @(t,momentum) 0.05;
    opts.momentum     = @(t) 0;
    
    dbncheckopts(opts,valid_fields);       
    dbn = dbnsetup(sizes, train_x, opts); 
    dbn = dbntrain(dbn, train_x, opts);
    
    nbb=train_x *(dbn.rbm{1}.W');
    reconstructed_x0 = 1./(1 + exp(-nbb));
    reconstructed_x = mapminmax('reverse',reconstructed_x0,ps); 

end