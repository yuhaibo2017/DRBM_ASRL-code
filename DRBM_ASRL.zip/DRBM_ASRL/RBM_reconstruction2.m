function [original_xn] = RBM_reconstruction2(reconstructed_xn, ndv)
    
    [train_x,ps]=mapminmax(reconstructed_xn,0,1);
    sizes = ndv;   % hidden layer size(The dimension of reconstructed space)
    [opts, valid_fields] = dbncreateopts();

    opts.numepochs = 10;
    opts.traintype = 'CD';
    opts.classRBM = 0;
    opts.y_train = train_x;
    opts.test_interval = 1;
    opts.train_func = @rbmgenerative;
    opts.init_type = 'cRBM';
    
    opts.learningrate = @(t,momentum) 0.05;
    opts.momentum     = @(t) 0;
    
    dbncheckopts(opts,valid_fields);       
    dbn = dbnsetup(sizes, train_x, opts); 
    dbn = dbntrain(dbn, train_x, opts);
    
    nbb=train_x *(dbn.rbm{1}.W');
    original_xn0 = 1./(1 + exp(-nbb));
    original_xn = mapminmax('reverse',original_xn0,ps); 
     

end