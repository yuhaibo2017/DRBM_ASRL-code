clc
clear

rng('default');
rng('shuffle');
warning('off');
runs=20;
format shorte

for jk=1:7
    funcnum=jk;
    if funcnum==1 %---Ellipsoid 
        fname='ellipsoid'
        Xmin=-5.12;Xmax=5.12;
        VRmin=-5.12;VRmax=5.12;
    elseif funcnum==2 %---Rosenbrock
        fname='rosenbrock'
        Xmin=-2.048;Xmax=2.048;
        VRmin=-2.048;VRmax=2.048;
    elseif funcnum==3 %---Ackley   
        fname='ackley'
        Xmin=-32.768;Xmax=32.768;
        VRmin=-32.768;VRmax=32.768;
    elseif funcnum==4 %---Griewank
        fname='griewank'
        Xmin=-600;Xmax=600;
        VRmin=-600;VRmax=600;
    elseif funcnum==5 %---Rastrigins 
        fname='rastrigin'
        Xmin=-5.12;Xmax=5.12;
        VRmin=-5.12;VRmax=5.12;
    elseif funcnum==6  % CEC 2005 function F10
        fname='benchmark_func'
        Xmin=-5;Xmax=5;
        VRmin=-5;VRmax=7;
    elseif funcnum==7  % CEC 2005 function /F19
        fname='benchmark_func3'
        Xmin=-5;Xmax=5;
        VRmin=-5;VRmax=5;
    end

    ndv = 150; 
    maxfes = 1000;% temination by maximum number of FES
parfor kkk = 1:runs
        kkk
        [fitnessbestn1] = DRBM_ASRL(fname,ndv,maxfes,Xmin,Xmax);
        fitnessbestn1 = sortrows(fitnessbestn1,'descend');        
        q(:,kkk)=fitnessbestn1; % all data

        c= size(fitnessbestn1,1);
        fitnessbestn1=zeros(maxfes,1); %clear
    end
        save(strcat('FE',num2str(maxfes),'_',num2str(fname),' runs=',num2str(runs),' Dim=',num2str(ndv)));
end

