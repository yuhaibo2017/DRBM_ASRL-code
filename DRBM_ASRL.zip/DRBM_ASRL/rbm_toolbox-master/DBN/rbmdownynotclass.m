function act_vis_y = rbmdownynotclass(rbm,hid_act)
%%RBMDOWNYNOTCLASS dummy function, returns 0
act_vis_y = 0;
