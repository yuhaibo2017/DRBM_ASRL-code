function X = sigm(P)
%%SIGM sigmoid function
    X = 1./(1+exp(-P));
end