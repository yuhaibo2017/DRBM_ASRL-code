function [ ret ] = softplus( a )
%SOFTPLUS calculates softplus as log(1+exp(a))
%ret = log(1+exp(a));
ret = log( bsxfun(@plus,1,exp(a)) );
end

